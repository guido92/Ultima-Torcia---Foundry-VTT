export class UltimaTorciaItem extends Item {
    /** @override */
    prepareData() {
        super.prepareData();
    }
}
